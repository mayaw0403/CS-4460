// JavaScript code goes here
thronesCharacters = [{
            "name": "Arya Stark",
            "status": "Alive",
            "current_location" : "Sailing uncharted seas",
            "house" : "Stark",
            "house_affiliations" : "Faceless Men",
            "probability_of_survival" : 99  
},
{
            "name" : "Tyrion Lannister",
            "status" : "Alive",
            "current_location" : "Casterly Rock",
            "house" : "Lannnister",
            "house_affiliations" : "House Baratheon of King's Landing and House Targaryen",
            "probability_of_survival" : 88
},
{
            "name" : "Daenerys Targaryen",
            "status" : "Dead",
            "current_location" : "n/a",
            "house" : "Targaryen",
            "house_affiliations" : "n/a",
            "probability_of_survival" : 0
},
{           "name" : "Jon Snow",
            "status" : "Alive",
            "current_location" : "The Wall",
            "house" : "Night's Watch",
            "house_affiliations" : "House Stark and Night's Watch",
            "probability_of_survival" : 50

}
]
console.log(thronesCharacters)