// DOM #main div element
var main = document.getElementById('main');

// **** Your JavaScript code goes here ****
thronesCharacters = [{
            "name": "Arya Stark",
            "status": "Alive",
            "current_location" : "Sailing uncharted seas",
            "house" : "Stark",
            "house_affiliations" : "Faceless Men",
            "probability_of_survival" : 99  
},
{
            "name" : "Tyrion Lannister",
            "status" : "Alive",
            "current_location" : "Casterly Rock",
            "house" : "Lannnister",
            "house_affiliations" : "House Baratheon of King's Landing and House Targaryen",
            "probability_of_survival" : 88
},
{
            "name" : "Daenerys Targaryen",
            "status" : "Dead",
            "current_location" : "n/a",
            "house" : "Targaryen",
            "house_affiliations" : "n/a",
            "probability_of_survival" : 0
},
{           "name" : "Jon Snow",
            "status" : "Alive",
            "current_location" : "The Wall",
            "house" : "Night's Watch",
            "house_affiliations" : "House Stark and Night's Watch",
            "probability_of_survival" : 50

}
]

function halfSurvival(character) {
    return (character.probability_of_survival)/2
}

for (i = 0; i < thronesCharacters.length; ++i) {
    current = thronesCharacters[i]
    if (current["name"] != "Arya Stark") {
        current["probability_of_survival"] = halfSurvival(current)
    }
}

function debugCharacters() {
    for (i = 0; i < thronesCharacters.length; ++i) {
        current = thronesCharacters[i]
        console.log(current.name)
        console.log(current.house)
        console.log(current.probability_of_survival)
        console.log(current.status)
    }
}

debugCharacters()

// document is the DOM, select the #main div
var main = document.getElementById("main");

// Create a new DOM element
var header = document.createElement("h3");
// Append the newly created <h3> element to #main
main.appendChild(header);
// Set the textContent to:
header.textContent = "My Favorite GoT Characters";

// // Create a new <div> element	
// var div1 = document.createElement("div");
// // Append the newly created <div> element to #main
// main.appendChild(div1);

// // Create a new <h5> element
// var name1 = document.createElement("h5");
// // Append the newly created <h5> element to your new div
// div1.appendChild(name1);
// // Set the textContent to the first characters name
// name1.textContent = thronesCharacters[0]["name"];

// // Create a new <p> element
// var survival1= document.createElement("p");
// // Append the newly created <p> element to your new div
// div1.appendChild(survival1);
// // Set the textContent to the first characters survival prob.
// survival1.textContent = "Survival %: " +thronesCharacters[0]["probability_of_survival"] +"%";

function displayCharacters() {
    for (i = 0; i < thronesCharacters.length; ++i) {
        var newdiv = document.createElement("div");
        main.appendChild(newdiv);
        var newname = document.createElement("h5");
        newname.className = "name-style"
        newdiv.appendChild(newname);
        newname.textContent = thronesCharacters[i]["name"];
        var newhou = document.createElement("p");
        newdiv.appendChild(newhou);
        newhou.textContent = "House: " +thronesCharacters[i]["house"];
        var newsurv= document.createElement("p");
        newdiv.appendChild(newsurv);
        newsurv.textContent = "Probability of Survival: " +thronesCharacters[i]["probability_of_survival"] +"%";
        var newstat = document.createElement("p");
        newdiv.appendChild(newstat);
        newstat.textContent = "Status: " +thronesCharacters[i]["status"];

    }
}

displayCharacters()