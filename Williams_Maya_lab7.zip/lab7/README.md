# CS_4460
# Design Specification

The goal of this visualization is to allow brushing and linking between two charts
showing information about colleges. This visualization contains 2 pages. The first page
shows a bubble chart of regions and the second shows 2 scatterplots with brushing and
linking interaction.