// **** Your JavaScript code goes here ****
d3.csv('./baseball_hr_leaders_2017.csv').then(function(dataset) {
	console.log("This is working");
	console.log(dataset[0]);

	dataset.forEach(function(player) {
		player.rank =+ player.rank;
		player.year =+ player.year;
		player.homeruns =+ player.homeruns;
	});

	console.log(dataset[0]);

	var name = [];
	var rank = [];
	var year = [];
	var homeruns = [];
	var i = 0;

	dataset.forEach(function(player) {
		name[i] = player['name'];
		rank[i] = player['rank'];
		year[i] = player['year'];
		homeruns[i] = player['homeruns'];
		i++;
	});

	i = 0;

	var p = d3.select("#homerun-leaders")
	.selectAll("p")
	.data(dataset)
	.enter()
	.append("p")
	.text(function(player,i) {
		return i + 1 + ". " + player['name'] + " with " + player['homeruns'] + " home runs"
	})
	.style("font-weight", function(player, i) {
		if (player['name'] == 'Giancarlo Stanton') {
			return 'bold';
		} else{
			return 'normal';
		}
	});

	var tr = d3.select("tbody")
	.selectAll("tr")
	.data(dataset)
	.enter()
	.append("tr");
	
	var td = tr.selectAll("td")
	.data(function (player, i) {
		var arr = []
		arr.push(player['name'])
		arr.unshift(player['rank'])
		arr.push(player['homeruns'])
		return arr
	})
	.enter()
	.append("td")
	.text(function (player, i) {
		console.log(player)
		return player;
	});
	
});